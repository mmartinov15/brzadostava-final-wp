<?php
/**
 * @package WordPress
 * @subpackage Chicago Desavanja
 * Template Name Posts: Single
 */
?>
<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js?ver=1.3.2'></script>
    <script type="text/javascript">
        $(function() {
            var offset = $(".skrol").offset();
            var topPadding = 0;
            $(window).scroll(function() {
                if ($(window).scrollTop() > offset.top) {
                    $(".skrol").stop().animate({
                        marginTop: $(window).scrollTop() - offset.top + topPadding
                    });
                } else {
                    $(".skrol").stop().animate({
                        marginTop: 0
                    });
                };
            });
        });
    </script>
<?php get_header(); ?>
<div id="main_klik"> 
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<?php the_content(); ?>
        <div class="clear"></div>
        
        <?php wp_link_pages(' '); ?>
         <?php edit_post_link('Izmeni', '', ''); ?>
       


<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>