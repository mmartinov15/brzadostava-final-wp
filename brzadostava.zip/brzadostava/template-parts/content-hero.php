<div class="hero container-fluid">
    <img class="img-responsive"
        src="https://rs.projects-abroad.net/v1/hero/indian-cuisine-south-africa-food-tours-product-5e146c7a97eb2.[1600].jpeg"
        alt="food">



    <div class="container hero__content">
        <div class="row justify-content-between align-self-center">
            <div class="col-lg-6 col-md-6 hero__content--left">
                

               <h2 style="text-transform: uppercase; "><?php echo single_cat_title( '', false ) ?></h2> 

                <ul class="row">
                    
                    <?php $args = array(
                    'type' => get_post_type(),
                    'orderby' => 'name',
                    'order' => 'ASC'
                    );
                    $tags = get_tags($args);

                    foreach($tags as $tag) {
                        echo '<li class="col px-1">' . $tag->name . '</li>';
                        
                       
                    }
                    ?>

                </ul>
                
               
                <h4><?php echo category_description(); ?></h4>
                
                <h4><?php echo $productCatMetaDesc = get_term_meta($term_id, 'wh_meta_desc', true);?></h4>
                
            </div>
           
        </div>
    </div>
</div>