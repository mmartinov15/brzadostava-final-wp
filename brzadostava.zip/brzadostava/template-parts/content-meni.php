<!-- another nav -->

<nav class="navbar catNav sticky-top">
    <div class="container-sm catNav__container">
        <div class="navbar-header">

            <span class="navbar-brand catNav__container--brand heading-3" href="#">
                <?php the_title();?></span>
        </div>

        <div class="navbar catNav__nav" id="myNavbar">
            <ul class="nav navbar-nav">
                
                <!--<li class="nav-item"><a class="nav-link" href="#section1">Rostilj</a></li>-->
                <!--<li class="nav-item"><a class="nav-link" href="#section2">Sendvici</a></li>-->
                <!--<li class="nav-item"><a class="nav-link" href="#section3">Deserti</a></li>-->

            </ul>

        </div>

    </div>


</nav>
<!-- <div class="card catNav__basket" id="basket">
   


    <!--<div class="card catNav__card">-->
    <!--    <h3 class="card-header text-center ">Vaša Porudzbina</h3>-->

    <!--    <div class="card-body mt-5 text-center catNav__card--body">-->

    <!--        <ul class="list-group list-group-flush">-->
    <!--            <li class="list-group-item">-->
    <!--                Pljeskavica: <span>250.00</span>-->
    <!--            </li>-->
    <!--            <li class="list-group-item">-->
    <!--                Ukupno za naplatu: <span>500.00</span>-->
    <!--            </li>-->

    <!--        </ul>-->
    <!--        <p class="text-muted pt-5">Napomena: Uračunata je cena dostave od 250 din</p>-->

    <!--        <input type="text" class="form-control" placeholder="Napomena za Porudzbinu"-->
    <!--            aria-label="Example text with button addon" aria-describedby="button-addon1">-->
    <!--    </div>-->

    <!--    <div class="card-footer text-center">-->
    <!--        <div class="col">-->
    <!--            <h4>Vasi Podaci:</h4>-->
    <!--            <hr>-->
    <!--            <div class="row">-->
    <!--                <div class="col">-->
    <!--                    <p>Adresa </p>-->
    <!--                </div>-->
    <!--                <div class="col">-->
    <!--                    <p>Mose Pijade 117 Pancevo</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="row">-->
    <!--                <div class="col">-->
    <!--                    <p>Telefon: </p>-->
    <!--                </div>-->
    <!--                <div class="col">-->
    <!--                    <p>013/266-887</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--        <hr>-->

    <!--        <a href="#" class="btn catNav__card--btn">Naruči !</a>-->
            <!-- <button type="button" class="btn continue" data-dismiss="modal" aria-label="Close">
    <!--                <span aria-hidden="true">Nastavi kupovinu</span>-->
    <!--            </button> -->
    <!--        <button type="button" class="btn continue" data-dismiss="modal" data-target="#basket">-->
    <!--            <span aria-hidden="true">Nastavi kupovinu</span>-->
    <!--        </button>-->

    <!--    </div>-->

    <!--</div>-->

<!-- </div> -->
<!--<div class="container-fluid categories_container">-->

<!--    <span id="section1" class="catNav__anchor">anchor</span>-->
<!--    <section class="container-fluid meni__section ml-0 pt-5">-->
<!--        <div class="container text-left">-->
<!--            <h2 class="meni__section--title">Rostilj</h2>-->
<!--        </div>-->

<!--        <div class="container-sm meni__section--dish-container">-->

<!--            <div class="meni__section--card">-->

<!--                <h5 class="item__card--title">Pljeskavica 170g</h5><br>-->
<!--                <p class="item__card--text"> Prilozi:</p>-->
<!--                <p class="item__card--desc">-->
<!--                    Lepinja ili tortilja? Ruska, šampinjoni, tartar, urnebes, zelena, paradajz, krastavci,-->
<!--                    vitaminska,-->
<!--                    luk, kupus, pečena paprika, ljuta peč.paprika</p>-->
                <!-- <p class="item__card--price">RSD 250.00</p> -->

<!--                <div class="row">-->
<!--                    <div class="col">RSD 250.00</div>-->

<!--                    <div class="col" style="text-align: end;">-->
<!--                        Kolicina:-->
<!--                    </div>-->
<!--                    <div class="col">-->
<!--                        <input type="text" class="form-control item__card--koliko" aria-label="Kolicina"-->
<!--                            aria-describedby="Kolicina">-->

<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </section>-->


<!--    <span id="section2" class="catNav__anchor">anchor</span>-->
<!--    <section class="container-fluid meni__section ml-0 pt-5">-->
<!--        <div class="container-sm text-left pt-4">-->
<!--            <h2 class="meni__section--title">Sendvici</h2>-->
<!--        </div>-->

<!--        <div class="container-sm meni__section">-->
<!--            <div class="row justify-content-between">-->
<!--                <div class="meni__section--card col">-->

<!--                    <h5 class="item__card--title">Sendvič šunka sir 280g </h5><br>-->


<!--                    <p class="item__card--text"> Prilozi:</p>-->
<!--                    <p class="item__card--desc">-->
<!--                        šampinjoni, pileća, tartar, urnebes, ruska, masline, susam, prolećna, kukuruz, zelena,-->
<!--                        kupus. luk, tucana paprika, kečap. Kajmak 70din.-->
<!--                    </p>-->
<!--                    <input type="text" class="form-control item__card--dodaci" aria-label="Dodaci"-->
<!--                        aria-describedby="Dodaci">-->



<!--                    <div class="row">-->
<!--                        <div class="col">RSD 250.00</div>-->

<!--                        <div class="col" style="text-align: end;">-->
<!--                            Kolicina:-->
<!--                        </div>-->
<!--                        <div class="col">-->
<!--                            <input type="text" class="form-control item__card--koliko" aria-label="Kolicina"-->
<!--                                aria-describedby="Kolicina">-->

<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->

<!--                <div class="meni__section--card col">-->

<!--                    <h5 class="item__card--title">Sendvič šunka sir 280g </h5><br>-->


<!--                    <p class="item__card--text"> Prilozi:</p>-->
<!--                    <p class="item__card--desc">-->
<!--                        šampinjoni, pileća, tartar, urnebes, ruska, masline, susam, prolećna, kukuruz, zelena,-->
<!--                        kupus. luk, tucana paprika, kečap. Kajmak 70din.-->
<!--                    </p>-->
<!--                    <input type="text" class="form-control item__card--dodaci" aria-label="Dodaci"-->
<!--                        aria-describedby="Dodaci">-->



<!--                    <div class="row">-->
<!--                        <div class="col">RSD 250.00</div>-->

<!--                        <div class="col" style="text-align: end;">-->
<!--                            Kolicina:-->
<!--                        </div>-->
<!--                        <div class="col">-->
<!--                            <input type="text" class="form-control item__card--koliko" aria-label="Kolicina"-->
<!--                                aria-describedby="Kolicina">-->

<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="w-100"></div>-->

<!--                <div class="meni__section--card col">-->

<!--                    <h5 class="item__card--title">Sendvič šunka sir 280g </h5><br>-->


<!--                    <p class="item__card--text"> Prilozi:</p>-->
<!--                    <p class="item__card--desc">-->
<!--                        šampinjoni, pileća, tartar, urnebes, ruska, masline, susam, prolećna, kukuruz, zelena,-->
<!--                        kupus. luk, tucana paprika, kečap. Kajmak 70din.-->
<!--                    </p>-->
<!--                    <input type="text" class="form-control item__card--dodaci" aria-label="Dodaci"-->
<!--                        aria-describedby="Dodaci">-->



<!--                    <div class="row">-->
<!--                        <div class="col">RSD 250.00</div>-->

<!--                        <div class="col" style="text-align: end;">-->
<!--                            Kolicina:-->
<!--                        </div>-->
<!--                        <div class="col">-->
<!--                            <input type="text" class="form-control item__card--koliko" aria-label="Kolicina"-->
<!--                                aria-describedby="Kolicina">-->

<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->

<!--                <div class="meni__section--card col">-->

<!--                    <h5 class="item__card--title">Sendvič šunka sir 280g </h5><br>-->
<!--                    <p class="item__card--text"> Prilozi:</p>-->
<!--                    <p class="item__card--desc">-->
<!--                        šampinjoni, pileća, tartar, urnebes, ruska, masline, susam, prolećna, kukuruz, zelena,-->
<!--                        kupus. luk, tucana paprika, kečap. Kajmak 70din.-->
<!--                    </p>-->
<!--                    <input type="text" class="form-control item__card--dodaci" aria-label="Dodaci"-->
<!--                        aria-describedby="Dodaci">-->

<!--                    <div class="row">-->
<!--                        <div class="col">RSD 250.00</div>-->

<!--                        <div class="col" style="text-align: end;">-->
<!--                            Kolicina:-->
<!--                        </div>-->
<!--                        <div class="col">-->
<!--                            <input type="text" class="form-control item__card--koliko" aria-label="Kolicina"-->
<!--                                aria-describedby="Kolicina">-->

<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->

<!--            </div>-->
<!--        </div>-->
<!--    </section>-->

<!--    <span id="section3" class="catNav__anchor">anchor</span>-->
<!--    <section class="container-fluid meni__section ml-0 pt-5">-->
<!--        <div class="container-sm text-left pt-4">-->
<!--            <h2 class="meni__section--title">Deserti</h2>-->
<!--        </div>-->

<!--        <div class="container-sm meni__section">-->
<!--            <div class="row justify-content-between">-->
<!--                <div class="meni__section--card col">-->

<!--                    <h5 class="item__card--title">Palačinke-->

<!--                    </h5><br>-->
<!--                    <p class="item__card--text"> Prilozi:</p>-->
<!--                    <p class="item__card--desc">-->
<!--                        Džemom,Nutelom</p>-->
<!--                    <input type="text" class="form-control item__card--dodaci" aria-label="Dodaci"-->
<!--                        aria-describedby="Dodaci">-->
<!--                    <div class="row">-->
<!--                        <div class="col">RSD 200.00</div>-->

<!--                        <div class="col" style="text-align: end;">-->
<!--                            Količina:-->
<!--                        </div>-->
<!--                        <div class="col">-->
<!--                            <input type="text" class="form-control item__card--koliko" aria-label="Kolicina"-->
<!--                                aria-describedby="Kolicina">-->

<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->

<!--                <div class="meni__section--card col">-->

<!--                    <h5 class="item__card--title">Palačinke-->

<!--                    </h5><br>-->
<!--                    <p class="item__card--text"> Prilozi:</p>-->
<!--                    <p class="item__card--desc">-->
<!--                        Džemom,Nutelom</p>-->
<!--                    <input type="text" class="form-control item__card--dodaci" aria-label="Dodaci"-->
<!--                        aria-describedby="Dodaci">-->
<!--                    <div class="row">-->
<!--                        <div class="col">RSD 200.00</div>-->

<!--                        <div class="col" style="text-align: end;">-->
<!--                            Količina:-->
<!--                        </div>-->
<!--                        <div class="col">-->
<!--                            <input type="text" class="form-control item__card--koliko" aria-label="Kolicina"-->
<!--                                aria-describedby="Kolicina">-->

<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="w-100"></div>-->
<!--            </div>-->

<!--        </div>-->
<!--    </section>-->

<!--</div>-->